+++
descrption = "Displays an expand'ble/collaps'ble sect'n o' text on yer plank"
title = "Expand"
+++
{{< piratify >}}