+++
alwaysopen = false
tags = ["children", "non-hidden"]
title = "Plank 2"
weight = 20
+++
{{< piratify >}}