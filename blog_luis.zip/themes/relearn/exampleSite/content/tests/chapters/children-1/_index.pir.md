+++
hidden = true
title = "Th' one an' only hidden child"
+++
{{< piratify >}}