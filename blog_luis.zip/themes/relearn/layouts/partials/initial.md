# Create this Page

You need to create a file for this page. You can either

- create an _index.md, index.md or otherly named markdown file (depending on Hugo's bundle type) in *content* folder and fill it with Markdown content
- create an *index.html* file in the <b>static</b> folder and fill the file with HTML content