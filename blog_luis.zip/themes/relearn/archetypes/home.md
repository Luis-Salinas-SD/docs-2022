+++
archetype = "home"
title = "{{ replace .Name "-" " " | title }}"
+++

Lorem Ipsum.
