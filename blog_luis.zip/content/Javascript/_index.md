+++
title = "Javascript"
chapter = true
weight = 5
pre = "<b>1. </b>"
+++

![Picard](../img/js/JavaScript-logo.png?width=10vw)

# Javascript

Una breve guia sobre Javascript y algunos ejemplos y ejercicios resueltos.

#### Recursos

**Literatura**

[Javascipt - Eloquent (libro)](https://eloquentjs-es.thedojo.mx/)

[Javacript - colección You don't know](https://daniel-morales.gitbook.io/javascript-avanzado-en-espanol/)

**Editores online**

- [jsFiddle](https://jsfiddle.net/)

- [StackBlitz](https://stackblitz.com/)
