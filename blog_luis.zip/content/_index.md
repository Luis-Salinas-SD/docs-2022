+++
title = "Bievenidos"
chapter = true
weight = 5
pre = "<b>1. </b>"
+++

# Bienvenidos

### Esta es un breve portafolio acerca de varios temas relacionados con la informatica e incluso con las tecnologías en general que se relacionan con la ciencia antes mencionada.
