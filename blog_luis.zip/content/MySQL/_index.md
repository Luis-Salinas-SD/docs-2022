+++
title = "MySQL"
chapter = true
weight = 15
pre = "<b>2. </b>"
+++

### Capitulo 2

# MySQL

Primero lo primero, tienes que saber cómo pronunciarlo: MY-ES-KYU-EL’

Es un sistema de gestión de bases de datos relacionales de código abierto (RDBMS, por sus siglas en inglés) con un modelo cliente-servidor. RDBMS es un software o servicio utilizado para crear y administrar bases de datos basadas en un modelo relacional
